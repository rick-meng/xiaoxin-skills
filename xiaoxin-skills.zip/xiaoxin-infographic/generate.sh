#!/bin/bash
# 蜡笔小新风格信息图生成脚本
# 用法: ./generate_xiaoxin_infographic.sh "主题"

set -e

# 检查参数
if [ $# -eq 0 ]; then
    echo "用法: $0 \"主题\""
    echo "示例: $0 \"Kimi 2.5 模型\""
    exit 1
fi

TOPIC="$1"
OUTPUT_DIR="/Users/wanglimeng/opencode/xinxitu"
FILENAME="$(echo "$TOPIC" | sed 's/[^a-zA-Z0-9\u4e00-\u9fa5]/_/g')_infographic.png"

echo "🎨 开始生成《蜡笔小新》风格信息图: $TOPIC"
echo "=========================================="

# 1. 创建笔记本
echo "📓 步骤 1/5: 创建 NotebookLM 笔记本..."
NOTEBOOK_JSON=$(notebooklm create "$TOPIC 信息图" --json)
NOTEBOOK_ID=$(echo "$NOTEBOOK_JSON" | grep -o '"id": "[^"]*"' | head -1 | cut -d'"' -f4)
echo "   ✓ 笔记本创建成功: $NOTEBOOK_ID"

# 2. 搜索并添加资料
echo "📚 步骤 2/5: 搜索相关资料..."
notebooklm source add-research "$TOPIC 核心能力 技术特点 性能指标" --mode fast --import-all || true
echo "   ✓ 资料添加完成"

# 3. 设置语言
echo "🌐 步骤 3/5: 设置语言为中文..."
notebooklm language set zh_Hans
echo "   ✓ 语言设置完成"

# 4. 生成信息图
echo "🖼️ 步骤 4/5: 生成信息图..."
PROMPT="参考《蜡笔小新》的漫画风格，以漫画一贯套路，介绍 $TOPIC 的核心内容。中文对白，彩色画面，特别注意中文文字生成的正确性。不要生成图标、logo。"
ARTIFACT_JSON=$(notebooklm generate infographic "$PROMPT" --orientation landscape --detail detailed --json)
ARTIFACT_ID=$(echo "$ARTIFACT_JSON" | grep -o '"task_id": "[^"]*"' | cut -d'"' -f4)
echo "   ✓ 信息图生成任务已启动: $ARTIFACT_ID"

# 5. 等待并下载
echo "⏳ 步骤 5/5: 等待生成完成并下载..."
echo "   这可能需要 5-15 分钟，请耐心等待..."

notebooklm artifact wait "$ARTIFACT_ID" -n "$NOTEBOOK_ID" --timeout 900

# 确保输出目录存在
mkdir -p "$OUTPUT_DIR"

# 下载信息图
notebooklm download infographic "$OUTPUT_DIR/$FILENAME" -a "$ARTIFACT_ID" -n "$NOTEBOOK_ID"

echo ""
echo "=========================================="
echo "✅ 信息图生成完成！"
echo "📁 文件位置: $OUTPUT_DIR/$FILENAME"
echo "=========================================="
