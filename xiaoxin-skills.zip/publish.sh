#!/bin/bash
# 自动发布脚本

echo "🚀 开始发布 xiaoxin-skills 到 GitHub..."
echo "=========================================="

# 检查是否在正确的目录
if [ ! -f "README.md" ]; then
    echo "❌ 错误：请在 github-skills 目录中运行此脚本"
    exit 1
fi

# 检查 GitHub CLI
if command -v gh &> /dev/null; then
    echo "✓ GitHub CLI 已安装"
    
    # 检查是否已登录
    if gh auth status &> /dev/null; then
        echo "✓ 已登录 GitHub"
    else
        echo "⚠️  需要登录 GitHub"
        gh auth login
    fi
    
    # 创建仓库并推送
    echo "📦 创建 GitHub 仓库..."
    gh repo create xiaoxin-skills \
        --public \
        --description "蜡笔小新风格的 OpenCode Skills - 一键生成信息图和演示文稿" \
        --source=. \
        --remote=origin \
        --push
        
    echo ""
    echo "✅ 发布成功！"
    echo "🌐 仓库地址: https://github.com/$(gh api user -q .login)/xiaoxin-skills"
    
else
    echo "⚠️  GitHub CLI 未安装，使用 Git 方式..."
    
    # 检查远程仓库
    if ! git remote | grep -q origin; then
        echo "🔗 添加远程仓库..."
        git remote add origin https://github.com/rick-meng/xiaoxin-skills.git
    fi
    
    # 推送代码
    echo "📤 推送代码到 GitHub..."
    git branch -M main
    git push -u origin main
    
    echo ""
    echo "✅ 发布成功！"
    echo "🌐 仓库地址: https://github.com/rick-meng/xiaoxin-skills"
fi

echo ""
echo "=========================================="
echo "🎉 完成！您的 skills 已发布到 GitHub。"
