# OpenCode Skills - 蜡笔小新风格生成器

这是一个包含两个 OpenCode Skill 的仓库，用于一键生成《蜡笔小新》漫画风格的内容。

## Skills 列表

### 1. xiaoxin-infographic
生成蜡笔小新漫画风格的信息图（PNG 格式）。

**使用方法：**
```
生成一个关于 [主题] 的蜡笔小新信息图
```

**工作流程：**
1. 创建 NotebookLM 笔记本
2. 搜索并添加相关资料
3. 生成蜡笔小新风格的信息图
4. 下载到 `/Users/wanglimeng/opencode/xinxitu/`

### 2. xiaoxin-slides
生成蜡笔小新漫画风格的演示文稿（PDF 格式）。

**使用方法：**
```
生成一个关于 [主题] 的演示文稿
```

**工作流程：**
1. 创建 NotebookLM 笔记本
2. 搜索并添加相关资料
3. 生成蜡笔小新风格的演示文稿
4. 下载到 `/Users/wanglimeng/opencode/yanshiwengao/`

## 依赖

- [notebooklm-py](https://github.com/teng-lin/notebooklm-py) - NotebookLM CLI 工具
- NotebookLM 账号（需要登录）
- OpenCode 或 Claude Code

## 安装

1. 安装 notebooklm-py：
```bash
pip install notebooklm-py
```

2. 登录 NotebookLM：
```bash
notebooklm login
```

3. 将 skills 复制到 OpenCode skills 目录：
```bash
cp -r xiaoxin-infographic ~/.opencode/skills/
cp -r xiaoxin-slides ~/.opencode/skills/
```

## 示例

### 生成信息图
```
用户：生成一个关于 Docker 的信息图
AI：好的，我来为您生成 Docker 的蜡笔小新风格信息图...
```

### 生成演示文稿
```
用户：生成一个关于 Kubernetes 的演示文稿
AI：好的，我来为您生成 Kubernetes 的蜡笔小新风格演示文稿...
```

## 特点

- 🎨 **蜡笔小新风格** - 采用经典的《蜡笔小新》漫画风格
- 📝 **中文内容** - 自动设置为简体中文
- 🔍 **自动资料搜集** - 自动搜索并添加相关资料
- ⚡ **一键生成** - 只需提供主题即可自动生成
- 📁 **自动保存** - 自动下载到指定目录

## 注意事项

- 生成过程需要 5-15 分钟
- 可能受 Google NotebookLM 速率限制
- 需要有效的 NotebookLM 账号

## License

MIT License

## Author

rick-meng

## 感谢

- [NotebookLM](https://notebooklm.google.com/) - Google 的 AI 研究助手
- [notebooklm-py](https://github.com/teng-lin/notebooklm-py) - NotebookLM Python CLI
